import numpy as np 
import sys
import csv 
import math 
from numpy import linalg as LA



#Takes the output from the adjacency matrix and put them in a touple list formatt
def listGeneration (file):
	origionalList = [] 
	for line in file :
		newLine = line.strip() 
		output = newLine.split(" ")
		outputMod = output[: -1]
		intMod = tuple([int(item) for item in outputMod])
		origionalList.append(intMod)
	return origionalList


# Function initN (n) takes a natural number n and 
# intialized a nxn matrix with all 0 
def initN (n)  : 
	return np.zeros((n,n))


def adjacencyMatrix(origionalList, matrix) :
	for (row,col) in origionalList:
		matrix [row][col] = 1
		matrix [col][row] = 1
	return matrix 


#Calculates the eigenvalues from given matrix
def eigenvalueCalc (matrix):
	result = []
	eigenVals = LA.eigvals(matrix)
	for value in eigenVals:
		result.append(value)
	return result


#sorts the eigenvalues of the adjacentcy matrix
def sortedEigenVals(list):
	alist = np.float_(list)
	for index in range(1,len(alist)):
		currentvalue = alist[index]
		position = index

		while position>0 and alist[position-1]>currentvalue:
			alist[position]=alist[position-1]
			position = position-1
		alist[position]=currentvalue
	return alist[::-1]


#Returns the top 10 eigenvalues of adjacency matrix in a comma separated list 
def top10EigenVals(list):
	eigenList = sortedEigenVals(list)
	top10 = eigenList[0:10]
	result = []
	for element in top10:
		result.append(element)
	return result


def addToFile(file, what):
    f = open(file, 'a').write(what) 

#Exports the List Generated to an Excel File 
def exportAsCSV(file, list1, list2):
	header = ['E1','E2','E3','E4','E5','E6','E7','E8','E9','E10']
	f = open(file, 'a').write("\n" + str(list1) + "\n")
	f = open(file, 'a').write(str(list2) + "\n")


def EigenExport(dest, file1, file2):
	DCIS = open (file1, "r")
	IDC =  open(file2, "r")
	DCIS_referenceList = listGeneration(DCIS)
	DCIS_referenceMatrix = initN(200)
	IDC_referenceList = listGeneration(IDC)
	IDC_referenceMatrix = initN(200)
	DCIS_matrixAnalysis = adjacencyMatrix(DCIS_referenceList, DCIS_referenceMatrix)
	IDC_matrixAnalysis = adjacencyMatrix(IDC_referenceList, IDC_referenceMatrix)
	DCIS_matrixEigenvalues = eigenvalueCalc(DCIS_matrixAnalysis)
	IDC_matrixEigenvalues = eigenvalueCalc(IDC_matrixAnalysis)
	DCISEig = top10EigenVals(DCIS_matrixEigenvalues)
	IDCEig = top10EigenVals(IDC_matrixEigenvalues)
	return exportAsCSV(dest, DCISEig, IDCEig)

EigenExport('test.csv', "AdjacencyMatrix1.txt", "AdjacencyMatrix2.txt")



 
