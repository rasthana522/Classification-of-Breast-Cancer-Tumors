import numpy as np 
from numpy import linalg as LA



B1_DCIS = open ("AdjacencyMatrix1.txt", "r")
B1_IDC =  open("AdjacencyMatrix2.txt", "r")



#matrixText = open ("AdjacencyMatrix.txt", "r")

#Takes the output from the adjacency matrix and put them in a touple list formatt
def listGeneration (file):
	origionalList = [] 
	for line in file :
		newLine = line.strip() 
		output = newLine.split(" ")
		outputMod = output[: -1]
		intMod = tuple([int(item) for item in outputMod])
		origionalList.append(intMod)
	return origionalList

# Function initN (n) takes a natural number n and 
# intialized a nxn matrix with all 0 

def initN (n)  : 
	return np.zeros((n,n))


def adjacencyMatrix(origionalList, matrix) :
	for (row,col) in origionalList:
		matrix [row][col] = 1
		matrix [col][row] = 1
	return matrix 

DCIS_referenceList = listGeneration(B1_DCIS)
DCIS_referenceMatrix = initN(200)

IDC_referenceList = listGeneration(B1_IDC)
IDC_referenceMatrix = initN(200)

DCIS_matrixAnalysis = adjacencyMatrix(DCIS_referenceList, DCIS_referenceMatrix)
IDC_matrixAnalysis = adjacencyMatrix(IDC_referenceList, IDC_referenceMatrix)

#referenceList = listGeneration (matrixText)
#refernceMatrix = initN(121)
#matrixAnalysis = adjacencyMatrix(referenceList, refernceMatrix)

#print DCIS_matrixAnalysis
#print IDC_matrixAnalysis

def eigenvalueCalc (matrix):
	return LA.eigvals(matrix)

def eigenSum (matrix) :
	return np.einsum("ij", matrix)

DCIS_matrixEigenvalues = eigenvalueCalc(DCIS_matrixAnalysis)
IDC_matrixEigenvalues = eigenvalueCalc(IDC_matrixAnalysis)

#print DCIS_matrixEigenvalues
#print IDC_matrixEigenvalues
#matrixEigenvalues = eigenvalueCalc(matrixAnalysis)

def listSum (list) :
	sum = 0 
	for item in list:
		sum += item 
	return sum 

def positiveListSum(list):
	sum = 0 
	for item in list:
		if item >= 0:
			sum += item 
		else:
			sum
	return sum 

def largestListVal(list):
	base = 0 
	for item in list:
		if item >= base:
			base = item
		else:
			base = base 
	return base 


def removeVal (val, L):
	L.remove(val)
	return L 
	

def secondLargestVal(arrayType):
	largestVal = largestListVal(arrayType)
	for index in xrange(len(arrayType)):
		if arrayType[index] == largestVal:
			return largestListVal(np.delete(arrayType, index, 0))

def tenLargesListVals(array, count, result):
	if count < 10:
		largestVal = largestListVal(array)
		for index in xrange(len(array)):
			if array[index] == largestVal:
				return tenLargesListVals(np.delete(array, index, 0), count + 1, np.append(result, [largestVal]))
	else:
	 return result 
		


A = [1,23,4,3,5,2,1,0,100,200,3,4,5,3,10,12,15]
#print tenLargesListVals(A, 0, [])	
 
print "List of Top 10 Eigenvalues for DCIS"
print tenLargesListVals(DCIS_matrixEigenvalues, 0, [])

print "List of Top 10 Eigenvalues for IDC"
print tenLargesListVals(IDC_matrixEigenvalues, 0, [])




 
